package com.corejava.models.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.Models.GameLog;

public class GameLog_Test {
	
	GameLog GameLog_expected;	GameLog GameLog_actual;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - GameLog MODEL");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - GameLog MODEL");
	}

	@Before
	public void setUp() throws Exception {

		GameLog_expected=new GameLog(10, 5, "E. Hosmer goes to third", 3, false, 4, 2, 1, 10,
				12, 4, 2, true);
		GameLog_actual=new GameLog();
		
//		
//		new GameLog(playlog, currentplay, result, inning, top, balls, strikes, outs, 
//				total_visitteam_runs, total_hometeam_runs, hitter_id, pitcher_id, score_updated);
		
		
		System.out.println("@Before TestSetters INTIZALIZE OBJECTS && TEST SETTERS");
		
		GameLog_actual.setPlayseries(10);
		GameLog_actual.setCurrentplay(5);
		GameLog_actual.setResult("E. Hosmer goes to third");
		GameLog_actual.setInning(3);
		GameLog_actual.setTop(false);
		GameLog_actual.setBalls(4);
		GameLog_actual.setStrikes(2);		
		GameLog_actual.setOuts(1);
		GameLog_actual.setVisitingteam_runs(10);		
		GameLog_actual.setHometeam_runs(12);
		GameLog_actual.setHitter_id(4);
		GameLog_actual.setPitcher_id(2);
		GameLog_actual.setScore_updated(true);		
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("@After FINISH METHOD");
	}

	@Test
	public final void testGetResults() {
		System.out.println("@Test TestGetters TEST GETTERS");

		assertTrue(GameLog_expected.getPlayseries()==GameLog_actual.getPlayseries());
		assertTrue(GameLog_expected.getCurrentplay()==GameLog_actual.getCurrentplay());
		assertTrue(GameLog_expected.getResult().equals(GameLog_actual.getResult()));
		assertTrue(GameLog_expected.getInning()==GameLog_actual.getInning());
		assertTrue(GameLog_expected.isTop()==GameLog_actual.isTop());
		assertTrue(GameLog_expected.getBalls()==GameLog_actual.getBalls());
		assertTrue(GameLog_expected.getStrikes()==GameLog_actual.getStrikes());
		assertTrue(GameLog_expected.getOuts()==GameLog_actual.getOuts());
		assertTrue(GameLog_expected.getVisitingteam_runs()==GameLog_actual.getVisitingteam_runs());
		assertTrue(GameLog_expected.getHometeam_runs()==GameLog_actual.getHometeam_runs());
		assertTrue(GameLog_expected.getHitter_id()==GameLog_actual.getHitter_id());
		assertTrue(GameLog_expected.getPitcher_id()==GameLog_actual.getPitcher_id());
		assertTrue(GameLog_expected.isScore_updated()==GameLog_actual.isScore_updated());
	}

	@Test
	public final void testSetResults() {
		System.out.println("@Test EqualsObjects TEST OBJECTS ARE EQUAL");
		
		assertEquals(GameLog_expected, GameLog_actual);
	}

}
