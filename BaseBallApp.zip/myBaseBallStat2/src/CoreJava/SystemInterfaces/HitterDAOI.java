package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Hitter;

public interface HitterDAOI {
	
	enum SQL{
		GET_HITTER_BY_ID("select * from player where player_id=?"),
		GET_ALL_HITTERS_BY_TEAM_ID("select * from player where team_id=?");
		
		private final String query;
		
		private SQL(String query) {
			this.query=query;
		}
		
		public String getQuery() {
			return this.query;
		}
	}
	
	List<Hitter> getAllHittersByTeamID(int team_id) throws SQLException, ClassNotFoundException, IOException;
	
	Hitter getHittererByID(int player_id) throws SQLException, ClassNotFoundException, IOException;
}
