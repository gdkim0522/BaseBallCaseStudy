package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Pitcher;

public interface PitcherDAOI {
	
	enum SQL{
		GET_PITCHER_BY_ID("select * from pitcher where team_id=? and player_id=?"),
		GET_PITCHERS_BY_TEAMID("select * from pitcher where team_id=?");
		
		private final String query;
		
		private SQL(String query) {
			this.query=query;
		}
		
		public String getQuery() {
			return this.query;
		}
	}
	
	Pitcher getPitcherByID(int team_id, int player_id) throws SQLException, ClassNotFoundException, IOException;
	
	List<Pitcher> getPitcherByTeamID(int team_id) throws ClassNotFoundException, IOException, SQLException;
}
