package CoreJava.Models;

public class Team {
	int team_id;
	String team_name;
	
	String city="Black";
	String color;
	String Stadium;
	
	int wins;
	int losses;

	
	public Team(int team_id, String team_name, String city, String color, String stadium, int wins, int losses) {
		this.team_id = team_id;
		this.team_name = team_name;
		this.city = city;
		this.color = "Black";
		this.Stadium = stadium;
		this.wins = wins;
		this.losses = losses;
	}
	
	public Team() {
		// TODO Auto-generated constructor stub
	}
	
	
	public boolean equals(Object object) {
		if(object instanceof Team) {
			Team other=(Team) object;
			boolean SameId=(this.team_id==other.getTeam_id());
			boolean SameName=this.team_name.equals(other.getTeam_name());
			boolean SameCity=this.city.equals(other.getCity());
			boolean SameColor=this.color.equals(other.getColor());
			boolean SameStadium=this.Stadium.equals(other.getStadium());
			boolean SameWins=(this.wins==other.getWins());
			boolean SameLosses=(this.losses==other.getLosses());
			
			if(SameId && SameName && SameCity && SameColor && SameStadium && SameWins && SameLosses)
				return true;
			else
				return false;
			
		}else
			return false;
		
	}


	public int getTeam_id() {
		return team_id;
	}
	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	public int getWins() {
		return wins;
	}
	public void setWins(int wins) {
		this.wins = wins;
	}
	public int getLosses() {
		return losses;
	}
	public void setLosses(int losses) {
		this.losses = losses;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
//	public String getManager() {
//		return Manager;
//	}
//	public void setManager(String manager) {
//		Manager = manager;
//	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getStadium() {
		return Stadium;
	}
	public void setStadium(String stadium) {
		this.Stadium = stadium;
	}
	
	
}
