package CoreJava.Models;

import org.hibernate.validator.constraints.NotEmpty;

import com.mybaseball.customAnnotations.PassConstraint;

public class User {
	
	@NotEmpty(message = "FirstName may not be empty")	
	private String firstName;
	
	@NotEmpty(message = "LastName may not be empty")
	private String lastName;
	
	@NotEmpty(message = "UserName may not be empty")
	private String userName;
	private String gender;
	
	@PassConstraint
	private String password;
//	
//	private ContactInfo contactInfo;
//	private PrivateInfo privateInfo;
//	
//	@DOBConstraint
	private String dob;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
//	public ContactInfo getContactInfo() {
//		return contactInfo;
//	}
//	public void setContactInfo(ContactInfo contactInfo) {
//		this.contactInfo = contactInfo;
//	}
//	public PrivateInfo getPrivateInfo() {
//		return privateInfo;
//	}
//	public void setPrivateInfo(PrivateInfo privateInfo) {
//		this.privateInfo = privateInfo;
//	}
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	
	
}
