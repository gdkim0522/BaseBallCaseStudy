package CoreJava.Models;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import CoreJava.DAOClasses.FileReaderCode;
import CoreJava.DAOClasses.HitterDAO;
import CoreJava.DAOClasses.PitcherDAO;
import CoreJava.DAOClasses.TeamDAO;

public class Game_122018 {
	//Status of each transaction
	boolean top;
	boolean RunnersOnBase;
	boolean isWalk;
	boolean scoreUpdated;
	int inning;
	int balls;
	int strikes;
	int outs;
	
	int[] visit_runs;
	int[] home_runs;
	int visitteam_runs;
	int hometeam_runs;
	
	int total_visitteam_runs;
	int total_hometeam_runs;	
	int visitteam_hits;
	int hometeam_hits;
	int visitteam_errors;
	int hometeam_errors;
	int playlog=1;
	
	int total_outs;
	GameLog gamelog;
	List<GameLog> gamelog_transactions;
	boolean isReset;
	int currentPlay;
	
	
	Team visit_team;
	Team home_team;
	List<Team> all_teams;
	
	//Hitters and Pitchers
	Map<Integer, Hitter> OnBase;
	List<Hitter> visit_Hitters;
	List<Hitter> home_Hitters;
	List<Pitcher> visit_Pitchers;
	List<Pitcher> home_Pitchers;
	
	
	Hitter current_Hitter;
	Pitcher current_HomePitcher;
	Pitcher current_VisitPitcher;
	
	int current_vishitter_index;
	int current_homhitter_index;
	//Set total number of innings played
	int inningbreak;
	int total_hitters=6;

	boolean isScoredonBB=false;
	int frombase;
	int tobase;
	boolean switchinning;
	String[] menu= {"Singles", "Doubles", "Triples", "Home Run",
			"Takes Ball", "Take Strike", "Swinging Strike",
			"Ground Out", "Fly Out"};
	
	String current_base_situation;
	String current_base_runner;
	boolean advanceRunner;
	
	
	
	
	
	public Hitter getCurrent_Hitter() {
		return current_Hitter;
	}

	public void setCurrent_Hitter(Hitter current_Hitter) {
		this.current_Hitter = current_Hitter;
	}

	public List<Hitter> getVisit_Hitters() {
		return visit_Hitters;
	}

	public void setVisit_Hitters(List<Hitter> visit_Hitters) {
		this.visit_Hitters = visit_Hitters;
	}

	public List<Hitter> getHome_Hitters() {
		return home_Hitters;
	}

	public void setHome_Hitters(List<Hitter> home_Hitters) {
		this.home_Hitters = home_Hitters;
	}

	public Pitcher getCurrent_HomePitcher() {
		return current_HomePitcher;
	}

	public void setCurrent_HomePitcher(Pitcher current_HomePitcher) {
		this.current_HomePitcher = current_HomePitcher;
	}

	public Pitcher getCurrent_VisitPitcher() {
		return current_VisitPitcher;
	}

	public void setCurrent_VisitPitcher(Pitcher current_VisitPitcher) {
		this.current_VisitPitcher = current_VisitPitcher;
	}

	public boolean isRunnersOnBase() {
		return RunnersOnBase;
	}

	public void setRunnersOnBase(boolean runnersOnBase) {
		RunnersOnBase = runnersOnBase;
	}

	public List<Pitcher> getVisit_Pitchers() {
		return visit_Pitchers;
	}

	public void setVisit_Pitchers(List<Pitcher> visit_Pitchers) {
		this.visit_Pitchers = visit_Pitchers;
	}

	public List<Pitcher> getHome_Pitchers() {
		return home_Pitchers;
	}

	public void setHome_Pitchers(List<Pitcher> home_Pitchers) {
		this.home_Pitchers = home_Pitchers;
	}

	public Team getVisit_team() {
		return visit_team;
	}

	public void setVisit_team(Team visit_team) {
		this.visit_team = visit_team;
	}

	public Team getHome_team() {
		return home_team;
	}

	public void setHome_team(Team home_team) {
		this.home_team = home_team;
	}
	
	

	public List<Team> getAll_teams() {
		return all_teams;
	}

	public void setAll_teams(List<Team> all_teams) {
		this.all_teams = all_teams;
	}

	public Game_122018() {
		try {
			//Intizalize lists and maps
			visit_Hitters=new LinkedList<Hitter>();
			home_Hitters=new LinkedList<Hitter>();
			OnBase=new HashMap<Integer,Hitter>();
			gamelog_transactions=new LinkedList<GameLog>();
			
			//Reset
			top=true;
			balls=0;
			strikes=0;
			outs=0;
//		isWalk=false;
//		switchinning=false;
			isScoredonBB=false;
			isReset=false;
			scoreUpdated=false;
			currentPlay=1;
			setBasesEmpty();
			advanceRunner=false;
			
			visit_runs=new int[9];
			home_runs=new int[9];
			total_visitteam_runs=0;
			total_hometeam_runs=0;
			
			visitteam_runs=0;
			hometeam_runs=0;
			visitteam_runs=0;
			hometeam_runs=0;		
			
			inning=1;
			inningbreak=1;
			
			TeamDAO teamDAO=new TeamDAO();
			all_teams=teamDAO.getAllTeams();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Game Constructor: " + e.getMessage());
		}
		
//		for(int i=1;i<OnBase.size()+1;i++) {
//			System.out.println("Runner on " + i + ": " + OnBase.get(i));
//		}
	}
	
	/**
	 * Get hitter and pitcher information based on team id and player_id.
	 * @param visit_team
	 * @param home_team
	 * @param vis_pitcher
	 * 
	 * @param home_pitcher
	 */
	
	
	public void getPitcherDAO(int visit_team, int home_team) {
		PitcherDAO pitcherDAO=new PitcherDAO();
		TeamDAO teamDAO=new TeamDAO();

		try {
			
			List<Pitcher>visit= pitcherDAO.getPitcherByTeamID(visit_team);
			List<Pitcher> visit_pitchers=new LinkedList<Pitcher>(visit);
			visit_Pitchers=visit_pitchers;
			
			List<Pitcher>home= pitcherDAO.getPitcherByTeamID(home_team);
			List<Pitcher> home_pitchers=new LinkedList<Pitcher>(home);
			home_Pitchers=home_pitchers;
			
			this.visit_team=teamDAO.getTeamById(visit_team);
			this.home_team=teamDAO.getTeamById(home_team);
			
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public void assignHittersDAO(int visit_team, int home_team, int vis_pitcher, int home_pitcher) {
		HitterDAO hitterDAO=new HitterDAO();
		PitcherDAO pitcherDAO=new PitcherDAO();
		
		try {
			List<Hitter> visit=hitterDAO.getAllHittersByTeamID(visit_team);
			List<Hitter> visit_hitters=new LinkedList<Hitter>(visit);
			visit_Hitters=visit_hitters;
			
			List<Hitter> home=hitterDAO.getAllHittersByTeamID(home_team);
			List<Hitter> home_hitters=new LinkedList<Hitter>(home);
			home_Hitters=home_hitters;
//			for (Hitter hitter : visit_hitters) {
//				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
//						hitter.getHits(),hitter.getRbi());
//			}
//			
//			System.out.println("===============");
//
//			for (Hitter hitter : home_hitters) {
//				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
//						hitter.getHits(),hitter.getRbi());
//			}
			
			current_VisitPitcher=pitcherDAO.getPitcherByID(visit_team, vis_pitcher);
			current_HomePitcher=pitcherDAO.getPitcherByID(home_team, home_pitcher);
			
			
			//Set the first visiting hitter
			current_vishitter_index=0;
			current_Hitter=visit_Hitters.get(current_vishitter_index);
			current_homhitter_index=-1 ;

			printTeams();
		
			System.out.println("LineUp Set.");	
			
			
//			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", visit_pitcher.getFullname(),
//					visit_pitcher.getInnings(),visit_pitcher.getRuns());
//			
//			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", home_pitcher.getFullname(),
//					home_pitcher.getInnings(),home_pitcher.getRuns());
			
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error msg: " +e.getMessage());
		}
	}
	
	public boolean isBasesEmpty() {
		
		
		if(OnBase.get(1)==null && OnBase.get(2)==null && OnBase.get(3)==null) {
			return true;
		}else {
			return false;
		}
		
	}
	
	
	/**
	 * Assign Hitters to a list which is at beginning.
	 * @param visit_team
	 * @param home_team
	 */
	public void assignHitters(int visit_team, int home_team, int vis_pitcher, int home_pitcher) {
		//Get player's data
		
		try {
			String players_array[]=getFiles("src/Players.csv").split("\n");
			String pitchers_array[]=getFiles("src/Pitchers.csv").split("\n");
			
			int i=0;
			//Loop thorugh every player
			for(;i<players_array.length;i++) {
				if(i==0)
					continue;
				
				//Get data field for each player
				String player_data[]=players_array[i].split(",");
				
				int playerId=Integer.parseInt(player_data[0]);
				int teamId=Integer.parseInt(player_data[1]);
				String playerName=player_data[2];
				int atBats=Integer.parseInt(player_data[3]);;
				int runs=Integer.parseInt(player_data[4]);;
				int hits=Integer.parseInt(player_data[5]);;
				int doubles=Integer.parseInt(player_data[6]);;
				int homeRuns=Integer.parseInt(player_data[7]);;
				int rbi=Integer.parseInt(player_data[8]);;			
				int walks=Integer.parseInt(player_data[9]);;
				int strikeouts=Integer.parseInt(player_data[10]);;
				
				//Check each player's team
				if(teamId==visit_team) {
					visit_Hitters.add(new Hitter(playerId, teamId, 
							playerName, atBats, runs, hits, doubles, 
							homeRuns, rbi, walks,strikeouts));
				}else if(teamId==home_team) {
					home_Hitters.add(new Hitter(playerId, teamId, 
							playerName, atBats, runs, hits, doubles, 
							homeRuns, rbi, walks,strikeouts));
				}
			}
			
			for(i=0;i<pitchers_array.length;i++) {
				if(i==0)
					continue;
				
				//Get data field for each player
				String pitcher_data[]=pitchers_array[i].split(",");
				int playerId=Integer.parseInt(pitcher_data[0]);
				int teamId=Integer.parseInt(pitcher_data[1]);
				String Name=pitcher_data[2];			
				int wins=Integer.parseInt(pitcher_data[3]);
				int loss=Integer.parseInt(pitcher_data[4]);
				float innings=Float.parseFloat(pitcher_data[5]);
				int hits=Integer.parseInt(pitcher_data[6]);
				int runs=Integer.parseInt(pitcher_data[7]);
				int walks=Integer.parseInt(pitcher_data[8]);
				int strikeouts=Integer.parseInt(pitcher_data[9]);
				
				//Assign starting pitcher
				if(playerId==vis_pitcher) {
					current_VisitPitcher=new Pitcher(playerId, teamId, Name, 
							wins, loss, innings, hits, runs, walks, strikeouts);
				}else if(playerId==home_pitcher) {
					current_HomePitcher=new Pitcher(playerId, teamId, Name, 
							wins, loss, innings, hits, runs, walks, strikeouts);
				}
				
				//Set the first visiting hitter
				current_vishitter_index=0;
				current_Hitter=visit_Hitters.get(current_vishitter_index);
				current_homhitter_index=-1 ;
			}
			printTeams();
			
			System.out.println("LineUp Set.");			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("EX: " +e.getMessage());
		}

	}
	
	void printTeams() {
		
		System.out.format("Starting Pitchers: %s vs %s.%n", current_HomePitcher.getFullname(),
				current_VisitPitcher.getFullname());
		System.out.println("======Visiting Team========");
		for (Hitter hitter : visit_Hitters) {
			System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
					hitter.getHits(),hitter.getRbi());
		}

		System.out.println("======Home Team==========");
		for (Hitter hitter : home_Hitters) {
			System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
					hitter.getHits(),hitter.getRbi());
		}
	}
	
	
	/**
	 * Update each array with run scored in that inning.
	 * @param inning
	 */
	void updateScoreBoard(int inning) {		
		visit_runs[inning-1]=visitteam_runs;
		home_runs[inning-1]=hometeam_runs;
		
		total_visitteam_runs=0;
		total_hometeam_runs=0;
		
		//Go through entire array and get total runs
		for(int i=0;i<inning;i++) {
			total_visitteam_runs+=visit_runs[i];
		}
		
		for(int i=0;i<inning;i++) {
			total_hometeam_runs+=home_runs[i];
		}
	}
	
	/**
	 * Get total score
	 */
	void getTotalScores() {
		
		total_visitteam_runs=0;
		total_hometeam_runs=0;
		
		for(int i=0;i<inning;i++) {
			total_visitteam_runs+=visit_runs[i];
			System.out.print(visit_runs[i] + " ");
		}
		
		System.out.print("Total_Visit: " + total_visitteam_runs);
		
		System.out.println();
		
		for(int i=0;i<inning;i++) {
			total_hometeam_runs+=home_runs[i];
			System.out.print(home_runs[i] + " ");
		}
		
		System.out.print("Total_Home: " + total_hometeam_runs);
	}
	
	
	/**
	 * Make Map null on each base.
	 */
	void setBasesEmpty() {
		RunnersOnBase=false;
		OnBase.put(1, null);
		OnBase.put(2, null);
		OnBase.put(3, null);		
	}
	
	/**
	 * Check if game is over after each transaction.
	 * @return  
	 */
	public boolean checkifGameOver() {
		boolean gameOver=false;
		
		//updateScoreBoard(inning);
		
		//Switch team hitter if there are three outs.
		if(outs==3) {
			System.out.println("THERE ARE THREE OUTS!!!");
			//Reset and empty bases.
			outs=0;
			setBasesEmpty();
			
			//Switch team hitters
			if(top) {
				outs=0;
				System.out.println("********HOME TEAM SWITCH***********");
				top=false;
			}else {
				outs=0;
				System.out.println("********VISIT TEAM SWITCH***********");				
				top=true;
				inning++;
				
				//Reset
				visitteam_runs=0;
				hometeam_runs=0;
			}

			//Get Next Hitter on other team when three outs
			get_currentHitter();
		}
	
		//Check if game is over when inning is past.
		if(inning>inningbreak && total_visitteam_runs==total_hometeam_runs) {
			System.out.println("TIE GAME!!!");
			gameOver=true;			
		}else if(top==false && inning==inningbreak && total_visitteam_runs<total_hometeam_runs){
			//Hone team wins
			System.out.println("Home Team Wins!!!");
			gameOver=true;
		}else if(inning>inningbreak && total_visitteam_runs>total_hometeam_runs) {
			//Visit Team wins
			System.out.println("Visitng Team Wins!!!");
			gameOver=true;			
		}
	
		return gameOver;
	}
	
	/**
	 * Set next current Hitter Object
	 */
	void get_currentHitter() {
		//Reset Count
		balls=0;
		strikes=0;
		
		//get next current hitter
		if(top==true) {
			//Reset or else get next hitter
			if(current_vishitter_index==visit_Hitters.size()-1)
				current_vishitter_index=0;
			else
				current_vishitter_index++;
			
			current_Hitter=visit_Hitters.get(current_vishitter_index);
		}else {
			if(current_homhitter_index==home_Hitters.size()-1)
				current_homhitter_index=0;
			else
				current_homhitter_index++;
			
			current_Hitter=home_Hitters.get(current_homhitter_index);
		}
	}
	
	/**
	 * Ask user for input regarding play transaction
	 */
	public void getGameMenu() {
		//Get the current hitter
		System.out.println("==============");
		System.out.println("*******************");
		System.out.println("Current Hitter: " + current_Hitter.getFullName());
		
		//Compute Bating Avg
		double avg=(float)current_Hitter.getHits()/current_Hitter.getAt_bats();
		String pattern=".###";
		DecimalFormat decimalFormat=new DecimalFormat(pattern);
		String format=decimalFormat.format(avg);
		
		//Show stats
		System.out.format("Avg: %s has %d HRS and %d RBI.%n", format,
				current_Hitter.getHomeruns(),current_Hitter.getRbi());
		
		//Current Base Situation
		for(int i=1;i<=OnBase.size();i++) {
			if(OnBase.get(i)!=null) {
				Hitter runner=OnBase.get(i);
				System.out.print(runner.getFullName() + " is on " + i + ". ");
			}
		}
		System.out.println("\n*******************");
		getTotalScores();	
		System.out.print("\n");
		//System.out.format("Visit: %d Home: %d.%n", total_visitteam_runs, total_hometeam_runs);
		System.out.format("%s %d -- ", (top)?"Top":"Bottom", inning);
		System.out.format("Balls: %d Strikes: %d Outs: %d.%n", balls,strikes,outs);

		System.out.println("==============");
		//Game Menu
		StringBuilder menuOptions=new StringBuilder();
		String[] menu= {"Singles", "Doubles", "Triples", "Home Run",
			"Takes Ball", "Take Strike", "Swinging Strike",
			"Ground Out", "Fly Out"};
		
		String build="";
		for(int i=0;i<menu.length;i++) {
			if(i==4 || i==7 || i==9)
				build+="\n";
			
			build+=i+1 + "-" + menu[i] + " ";
		}
			
		menuOptions.append(build);

		System.out.println("Pick an option:");
		System.out.println(menuOptions);		
	}
	
	/**
	 *	Record transaction based on user choice and go to next transaction. 
	 */
	public void recordTransaction(int pick) {

		String result;
		String pitcherName;
		int pitcher_id;
		int hitter_id;

		try {
			if(top==true) {
				pitcherName=current_HomePitcher.getFullname();
				pitcher_id=current_HomePitcher.getPitcher_id();
				//System.out.println("HOME PITCHER");
			}else {
				pitcherName=current_VisitPitcher.getFullname();
				pitcher_id=current_VisitPitcher.getPitcher_id();
						
				//System.out.println("VISIT PITCHER");
			}
			
			//Get hitter name and id
			hitter_id=current_Hitter.getPlayer_id();
			result=current_Hitter.getFullName() + " " + menu[pick-1].toLowerCase() + " against "
					+ pitcherName;		
			
			//Check options
			//Check for hits
			if(pick>=1 && pick<=4) {
				isReset=true;
				//Score All if "Home Run"
				if(pick==4)
					scoreAll();
				
				//If other hits, advance the runners.
				if(RunnersOnBase) {
					//setBaseSituations(pick);
				}
				
				//If player gets hits, put him on base
				if(pick==1) {
					updateHitterStats(current_Hitter, 1, 1, 0, 0, 0, 0, 0, 0);
					OnBase.put(1, current_Hitter);
				}else if (pick==2) {
					updateHitterStats(current_Hitter, 1, 1, 0, 1, 0, 0, 0, 0);
					OnBase.put(2, current_Hitter);
				}else if (pick==3) {
					updateHitterStats(current_Hitter, 1, 1, 0, 0, 0, 0, 0, 0);
					OnBase.put(3, current_Hitter);
				}
				if(pick!=4) {
					RunnersOnBase=true;
				}
				
				//Get Next hitter
				get_currentHitter();
			}else if (pick>=8 && pick<=9) {
				//Record outs.
				isReset=true;
				outs++;
				updateHitterStats(current_Hitter, 1, 0, 0, 0, 0, 0, 0, 0);
				
				//Get Next hitter
				if(outs<3)
					get_currentHitter();
			}else if(pick==5) {
				balls++;
				//if balls=4, then the player walks
				if(balls==4) {
					isReset=true;
					if(RunnersOnBase) {
						//setBaseSituations(scanner);
					}
					
					//If player walks, put him on base
					//OnBase.put(1, current_Hitter);
					//setBaseSituation(1, current_Hitter);
					updateHitterStats(current_Hitter, 0, 0, 0, 0, 0, 0, 1, 0);

					RunnersOnBase=true;
					get_currentHitter();									
				}
			}else if(pick==6 || pick==7) {
				strikes++;
				//if strikes=3, then the player strikes out
				if(strikes==3) {
					isReset=true;
					updateHitterStats(current_Hitter, 1, 0, 0, 0, 0, 0, 0, 1);
					outs++;
					if(outs<3)
						get_currentHitter();
				}
			}	
			
			//Update Scoreboard
			updateScoreBoard(inning);

			//Record transaction and put into collection.
			//currentPlay
			gamelog_transactions.add(
			new GameLog(playlog,currentPlay, result,inning,top,balls,strikes,outs,total_visitteam_runs,
					total_hometeam_runs,hitter_id,pitcher_id,scoreUpdated));
			scoreUpdated=false;
			//Play_count,result, inning,top,balls,strike,out,visit_score,home_score, hitterid,pitcher_id
			//System.out.format("Ball: %d Strike: %d Out:%d Visit: %d Home: %d.%n", balls,
			//		strikes,outs,total_visitteam_runs,total_hometeam_runs);
			System.out.println("Play " + playlog + ": " +result);
			
			//Reset is true
			if(isReset) {
				currentPlay=1;
				isReset=false;
			}else
				currentPlay++;
			
			playlog++;			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("--------Error at recordTransaction: " + e.getMessage());
		}
		//Get pitcher name and id

	}
	
	
	/**
	 * if player hits home run, all players score
	 * Update hitter statistics
	 */
	public void scoreAll() {
		int run_scored=0;
		
		//Empty the base
		for(int i=1;i<=OnBase.size();++i) {
			if(OnBase.get(i) != null) {
				Hitter runner=OnBase.get(i);
				updateHitterStats(runner, 0, 0, 1, 0, 0, 0, 0, 0);
				OnBase.put(i, null);
				run_scored++;
			}
		}
		
		//bases are empty
		RunnersOnBase=false;
		setBasesEmpty();
		
		//int rbi =current_Hitter.getRbi();
		int rbi=++run_scored;

		updateHitterStats(current_Hitter, 1, 1, 1, 0, 1, rbi, 0, 0);
		
		//Update ScoreBoard
		scoreUpdated=true;
		if(top) {
			visitteam_runs+=run_scored;
		}else
			hometeam_runs+=run_scored;	
	}
	
	/**
	 * Update Hitter Stats for Today
	 */
	void updateHitterStats(Hitter current_Hitter,int at_bat,int hits, 
			int runs, int doubles, int hr, int rbi,int walks, int so) {
		//Get stats and update with parameters
		int today_ab=current_Hitter.getTodayStats().getAt_bats()+at_bat;
		int today_hit=current_Hitter.getTodayStats().getHits()+hits;
		int today_run=current_Hitter.getTodayStats().getRuns()+runs;		
		int today_double=current_Hitter.getTodayStats().getDoubles()+doubles;
		int today_homerun=current_Hitter.getTodayStats().getHomeruns()+hr;
		int today_rbi=current_Hitter.getTodayStats().getRbi()+rbi;
		int today_walk=current_Hitter.getTodayStats().getWalks()+walks;
		int today_strike=current_Hitter.getTodayStats().getStrikeouts()+so;
		
		//Set the new stat values
		current_Hitter.getTodayStats().setAt_bats(today_ab);
		current_Hitter.getTodayStats().setHits(today_hit);
		current_Hitter.getTodayStats().setRuns(today_run);
		current_Hitter.getTodayStats().setDoubles(today_double);
		current_Hitter.getTodayStats().setHomeruns(today_homerun);
		current_Hitter.getTodayStats().setRbi(today_rbi);
		current_Hitter.getTodayStats().setWalks(today_walk);
		current_Hitter.getTodayStats().setStrikeouts(today_strike);
	}
	
	/**
	 * Advance runner if not home run
	 */
	public void setBaseSituations(int hit){
		
		if(!OnBase.isEmpty()) {
			//Ask for user input on how to advance runners
			for(int i=3;i>0;i--) {
				//Get the player on base.
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					
					while(true) {
						
						if(i<3) {
							//System.out.println("3-Stay 4-Home");
							System.out.format("%s on %d goes to: ", runner.getFullName(), i);
						}
						
						//Runner on 2nd
						if (i==2) { 
							//Single and empty first
							if(hit==1 && OnBase.get(1)==null) {
								current_base_situation="2-Stay 3-Third 4-Home";
								//System.out.println("2-Stay 3-Third 4-Home");
							}else if(hit==1 && OnBase.get(1)!=null) {
								current_base_situation="3-Third 4-Home";
								//System.out.println("3-Third 4-Home");
							}else if (hit==2) {
								current_base_situation="3-Third 4-Home";
								//System.out.println("3-Third 4-Home");
							}else if (hit==3) {
								current_base_situation="4-Home";
								//System.out.println("4-Home");
							}
						}else if (i==1) {
							if(hit==1) {
								current_base_situation="2-Second 3-Third 4-Home";
								//System.out.println("2-Second 3-Third 4-Home");
							}else if (hit==2) {
								current_base_situation="3-Third 4-Home";
								//System.out.println("3-Third 4-Home");
							}else if (hit==3) {
								current_base_situation="4-Home";
								//System.out.println("4-Home");
							}
						}
						
						int pick=0;
						
						if(i<=2) {
							//pick=scanner.nextInt();
						}else if (i==3) {
							pick=4;
						}
						
						//Invalid input
						if(pick<1 || pick>4) {
							System.out.println("Invalid input");
						}else {
//							if(i==3)
//								pick=4;
								
							advanceRunner(i, pick);
							break;
						}
					}
				}
			}
		}
			
//		if(ballGame.onThird!=null) {
//			runner=ballGame.onThird;
//			System.out.println(runner.getFullName() + " on third goes to:");
//			System.out.println("4- Home");
//			base=scanner.nextInt();
//			if (base==4 && current_Top==true) {
//				ballGame.vist_score++;
//			}else if (base==4 && current_Top==false) {
//				ballGame.home_score++;
//			}
//			ballGame.onThird=null;
//		}
	}
	
	/**
	 * if current_hitter walks, advance runners
	 */	
	void setBaseSituation(int base,Hitter hitter) {
		
		isScoredonBB=false;
		
		if(base==4) {
			updateHitterStats(hitter, 0, 0, 1, 0, 0, 0, 0, 0);
			scoreUpdated=true;
			isScoredonBB=true;
			if(top) {
				visitteam_runs++;
			}else
				hometeam_runs++;
			
			OnBase.put(4, null);
			
			return;
		}		

		//Get the runner on each base
		Hitter runner=OnBase.get(base);
		
		if(runner!=null) {
			setBaseSituation(base+1,runner);
		}
		
		//Update rbi
		if(isScoredonBB && base==1)
			updateHitterStats(hitter, 0, 0, 0, 0, 0, 1, 0, 0);
		
		//Put runner on base
		System.out.println(hitter.getFullName() + " goes to " + base);
		OnBase.put(base, hitter);
	}

	
	/**
	 * Advance the runner from a base to the another base
	 * @param frombase
	 * @param tobase
	 */
	
	public void advanceRunner(int frombase, int tobase) {
		//Get runner from base he start on
		Hitter runner=OnBase.get(frombase);
		
		//If runner score
		if(tobase==4) {
			//update run stats
			scoreUpdated=true;
//			int runscored=runner.getRuns();
//			runner.setRuns(++runscored);
			
			int runscored=runner.getTodayStats().getRuns();
			runner.getTodayStats().setRuns(++runscored);
			
			//Update hitter rbi
			int rbi=current_Hitter.getTodayStats().getRbi();
			current_Hitter.getTodayStats().setRbi(++rbi);
			
			//Update ScoreBoard
			if(top) {
				visitteam_runs++;
			}else
				hometeam_runs++;
			
			//update frombase
			OnBase.put(frombase, null);
		}else if (tobase==3) {
			//if runner goes to third
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);
		}else if(tobase==2) {
			//if runner goes to second
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);			
		}else if(tobase==1) {
			//if runner goes to first
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);			
		}
	}
	
	
	public void getFinalScore() {
		System.out.println("FINAL SCORE");
		System.out.format("Visit:%d Home:%d %n", total_visitteam_runs,
				total_hometeam_runs);
		
		System.out.println("======Visiting Team========");
		
		System.out.println("AB H R 2B HR RBI BB SO");
		for (Hitter hitter : visit_Hitters) {
			System.out.format("%d  %d %d %d  %d  %d   %d  %d -- %s %n",
					hitter.getTodayStats().getAt_bats(),hitter.getTodayStats().getHits(),
					hitter.getTodayStats().getRuns(),
					hitter.getTodayStats().getDoubles(),hitter.getTodayStats().getHomeruns(),
					hitter.getTodayStats().getRbi(),hitter.getTodayStats().getWalks(),
					hitter.getTodayStats().getStrikeouts(),hitter.getFullName());
		}

		System.out.println("======Home Team==========");
		
		System.out.println("AB H R 2B HR RBI BB SO");
		for (Hitter hitter : home_Hitters) {
			System.out.format("%d  %d %d %d  %d  %d   %d  %d -- %s %n",
					hitter.getTodayStats().getAt_bats(),hitter.getTodayStats().getHits(),
					hitter.getTodayStats().getRuns(),
					hitter.getTodayStats().getDoubles(),hitter.getTodayStats().getHomeruns(),
					hitter.getTodayStats().getRbi(),hitter.getTodayStats().getWalks(),
					hitter.getTodayStats().getStrikeouts(),hitter.getFullName());
		}
	}
	
	String getFiles(String fileName) {
		String teamVisit;
		teamVisit=FileReaderCode.readCsvFile(fileName);
		
		return teamVisit;
	}
	
	public void savePlayers() throws IOException {
		String FileRead="";
		String playerdata = "";
		String gameLogdata = "";
		String CD=",";
		String NL="\n";

		try {
			int i=1;

			//Output player data
			playerdata=playerdata.concat("Hitter_ID"+CD);
			playerdata=playerdata.concat("AB"+CD);
			playerdata=playerdata.concat("H"+CD);
			playerdata=playerdata.concat("R"+CD);
			playerdata=playerdata.concat("2B"+CD);
			playerdata=playerdata.concat("HR"+CD);			
			playerdata=playerdata.concat("RBI"+CD);
			playerdata=playerdata.concat("BB"+CD);
			playerdata=playerdata.concat("SO"+NL);
			
			for (Hitter hitter : visit_Hitters) {
				playerdata=playerdata.concat(hitter.getPlayer_id()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getAt_bats()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHits()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getRuns()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getDoubles()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHomeruns()+CD);			
				playerdata=playerdata.concat(hitter.getTodayStats().getRbi()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getWalks()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getStrikeouts()+NL);
			}
			
			for (Hitter hitter : home_Hitters) {
				playerdata=playerdata.concat(hitter.getPlayer_id()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getAt_bats()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHits()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getRuns()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getDoubles()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHomeruns()+CD);			
				playerdata=playerdata.concat(hitter.getTodayStats().getRbi()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getWalks()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getStrikeouts()+NL);
			}
			
			i=1;

			//Output Game Log Data
			gameLogdata=gameLogdata.concat("PlaySeries"+CD);
			gameLogdata=gameLogdata.concat("CurrentPlay"+CD);
			gameLogdata=gameLogdata.concat("Result"+CD);
			gameLogdata=gameLogdata.concat("Inning"+CD);
			gameLogdata=gameLogdata.concat("Top"+CD);
			gameLogdata=gameLogdata.concat("Balls"+CD);
			gameLogdata=gameLogdata.concat("Strikes"+CD);
			gameLogdata=gameLogdata.concat("Outs"+CD);
			gameLogdata=gameLogdata.concat("Visitingteam_runs"+CD);
			gameLogdata=gameLogdata.concat("Hometeam_runs"+CD);
			gameLogdata=gameLogdata.concat("Hitter_id"+CD);
			gameLogdata=gameLogdata.concat("Pitcher_id"+CD);
			gameLogdata=gameLogdata.concat("Score_updated"+NL);
			
			for (GameLog gameLog : gamelog_transactions) {
				if(i==gamelog_transactions.size()) {
					gameLogdata=gameLogdata.concat(gameLog.getPlayseries()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getCurrentplay()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getResult()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getInning()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isTop()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getBalls()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getStrikes()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getOuts()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getVisitingteam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHometeam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHitter_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getPitcher_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isScore_updated()+"");
//						gameLog.getResult()+CD+gameLog.getInning()+CD+gameLog.getBalls()+CD+
//						gameLog.getStrikes()+CD+gameLog.getOuts()+CD+gameLog.getVisitingteam_runs()
//						+CD+gameLog.getHometeam_runs()+CD+gameLog.getPitcher_id()+CD);
				}else {
//				new GameLog(playlog,currentPlay, result,inning,top,balls,strikes,outs,total_visitteam_runs,
//						total_hometeam_runs,hitter_id,pitcher_id));
					gameLogdata=gameLogdata.concat(gameLog.getPlayseries()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getCurrentplay()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getResult()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getInning()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isTop()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getBalls()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getStrikes()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getOuts()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getVisitingteam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHometeam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHitter_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getPitcher_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isScore_updated()+NL);
					
				}
				i++;
			}
			
			FileReaderCode.WriteFileCSV("src/playerdata.csv", playerdata);
			FileReaderCode.WriteFileCSV("src/gamelog.csv", gameLogdata);
			System.out.println("File saved!!!!!!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error saving Game Log Data");;
		}
		
	}
}
