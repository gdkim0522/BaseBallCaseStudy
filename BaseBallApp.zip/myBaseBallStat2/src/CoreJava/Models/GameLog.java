package CoreJava.Models;

//Tracks all instances of the game results.
public class GameLog {
	
	int playseries;
	int currentplay;
	String date;
	String time; 
	boolean top;
	boolean score_updated;
	int inning;

	int balls;
	int strikes;
	int outs;
	
	int visiting_id;
	int home_id;	
	int hitter_id;
	int pitcher_id;
	String result;
	
	Player onFirst;
	Player onSecond;
	Player onThird;
	Player onHome;
	
	int hometeam_runs;
	int visitingteam_runs;
	int hometeam_hits;
	int visitingteam_hits;

	
	public GameLog() {
		
	}
	
	public GameLog(int playlog, Integer currentplay, String result, int inning, boolean top, int balls, int strikes, int outs,
			int total_visitteam_runs, int total_hometeam_runs,int hitter_id,int pitcher_id, boolean score_updated) {
		this.playseries=playlog;
		this.currentplay=currentplay;
		this.result=result;
		this.inning=inning;
		this.top=top;
		this.balls=balls;
		this.strikes=strikes;
		this.outs=outs;
		this.visitingteam_runs=total_visitteam_runs;
		this.hometeam_runs=total_hometeam_runs;
		this.hitter_id=hitter_id;
		this.pitcher_id=pitcher_id;
		this.score_updated=score_updated;
	}
	
	

	public boolean equals(Object object) {
		if(object instanceof GameLog) {
			GameLog other=(GameLog) object;
			boolean SamePlaySeries=(this.playseries==other.getPlayseries());
			boolean SameCurrentPlay=(this.currentplay==other.getCurrentplay());
			boolean SameResult=this.result.equals(other.getResult());
			boolean SameInning=(this.inning==other.getInning());
			boolean SameTop=(this.top==other.isTop());
			boolean SameBalls=(this.balls==other.getBalls());			
			boolean SameStrikes=(this.strikes==other.getStrikes());
			boolean SameOuts=(this.outs==other.getOuts());

			boolean SameVisitRuns=(this.visitingteam_runs==other.getVisitingteam_runs());			
			boolean SameHomeRuns=(this.hometeam_runs==other.getHometeam_runs());
			boolean SameHitterID=(this.hitter_id==other.getHitter_id());
			boolean SamePitcherID=(this.pitcher_id==other.getPitcher_id());
			boolean SameScoreUpdated=(this.score_updated==other.isScore_updated());
			
			
			
			if(SamePlaySeries && SameCurrentPlay && SameResult && SameInning && SameTop && SameBalls && 
					SameStrikes && SameOuts && SameVisitRuns && SameHomeRuns && SameHitterID && SamePitcherID && SameScoreUpdated)
				return true;
			else
				return false;
			
		}else
			return false;
	}	
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getVisiting_id() {
		return visiting_id;
	}
	public void setVisiting_id(int visiting_id) {
		this.visiting_id = visiting_id;
	}
	public int getHome_id() {
		return home_id;
	}
	public void setHome_id(int home_id) {
		this.home_id = home_id;
	}
	public boolean isTop() {
		return top;
	}
	public void setTop(boolean top) {
		this.top = top;
	}
	public int getInning() {
		return inning;
	}
	public void setInning(int inning) {
		this.inning = inning;
	}
	public int getBalls() {
		return balls;
	}
	public void setBalls(int balls) {
		this.balls = balls;
	}
	public int getStrikes() {
		return strikes;
	}
	public void setStrikes(int strikes) {
		this.strikes = strikes;
	}
	public int getOuts() {
		return outs;
	}
	public void setOuts(int outs) {
		this.outs = outs;
	}

	public int getPitcher_id() {
		return pitcher_id;
	}
	public void setPitcher_id(int pitcher_id) {
		this.pitcher_id = pitcher_id;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public int getHometeam_runs() {
		return hometeam_runs;
	}
	public void setHometeam_runs(int hometeam_runs) {
		this.hometeam_runs = hometeam_runs;
	}
	public int getVisitingteam_runs() {
		return visitingteam_runs;
	}
	public void setVisitingteam_runs(int visitingteam_runs) {
		this.visitingteam_runs = visitingteam_runs;
	}
	public int getHometeam_hits() {
		return hometeam_hits;
	}
	public void setHometeam_hits(int hometeam_hits) {
		this.hometeam_hits = hometeam_hits;
	}
	public int getVisitingteam_hits() {
		return visitingteam_hits;
	}
	public void setVisitingteam_hits(int visitingteam_hits) {
		this.visitingteam_hits = visitingteam_hits;
	}
	public int getPlayseries() {
		return playseries;
	}
	public void setPlayseries(int playseries) {
		this.playseries = playseries;
	}
	public Player getOnFirst() {
		return onFirst;
	}
	public void setOnFirst(Player onFirst) {
		this.onFirst = onFirst;
	}
	public Player getOnSecond() {
		return onSecond;
	}
	public void setOnSecond(Player onSecond) {
		this.onSecond = onSecond;
	}
	public Player getOnThird() {
		return onThird;
	}
	public void setOnThird(Player onThird) {
		this.onThird = onThird;
	}
	public Player getOnHome() {
		return onHome;
	}
	public void setOnHome(Player onHome) {
		this.onHome = onHome;
	}

	public int getCurrentplay() {
		return currentplay;
	}

	public void setCurrentplay(int currentplay) {
		this.currentplay = currentplay;
	}

	public int getHitter_id() {
		return hitter_id;
	}

	public void setHitter_id(int hitter_id) {
		this.hitter_id = hitter_id;
	}

	public boolean isScore_updated() {
		return score_updated;
	}

	public void setScore_updated(boolean score_updated) {
		this.score_updated = score_updated;
	}
	
	

}
