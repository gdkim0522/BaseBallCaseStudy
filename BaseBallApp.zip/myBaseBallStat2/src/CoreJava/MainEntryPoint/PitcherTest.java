package CoreJava.MainEntryPoint;

import CoreJava.Models.Game_122018;
import CoreJava.Models.Pitcher;

public class PitcherTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game_122018 ballgame=new Game_122018();
		ballgame.assignHittersDAO(1, 2, 1 ,3);
		Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
		Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();

		System.out.format("Name is %s%n", home_pitcher.getFullname());
		System.out.format("Name is %s%n", visit_pitcher.getFullname());
	}

}
