package CoreJava.MainEntryPoint;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import CoreJava.DAOClasses.HitterDAO;
import CoreJava.DAOClasses.PitcherDAO;
import CoreJava.Models.Hitter;
import CoreJava.Models.Pitcher;

public class Hitter_MainRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HitterDAO hitterDAO=new HitterDAO();
		PitcherDAO pitcherDAO=new PitcherDAO();
//		List<Hitter> visit_hitters=new LinkedList<Hitter>();
//		List<Hitter> home_hitters=new LinkedList<Hitter>();
		
		
		try {
			List<Hitter> visit=hitterDAO.getAllHittersByTeamID(1);
			List<Hitter> visit_hitters=new LinkedList<Hitter>(visit);
			
			List<Hitter> home=hitterDAO.getAllHittersByTeamID(2);
			List<Hitter> home_hitters=new LinkedList<Hitter>(home);
			
			for (Hitter hitter : visit_hitters) {
				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
						hitter.getHits(),hitter.getRbi());
			}
			
			System.out.println("===============");

			for (Hitter hitter : home_hitters) {
				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
						hitter.getHits(),hitter.getRbi());
			}
			
			Pitcher visit_pitcher=pitcherDAO.getPitcherByID(1, 1);
			Pitcher home_pitcher=pitcherDAO.getPitcherByID(2, 3);
			
			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", visit_pitcher.getFullname(),
					visit_pitcher.getInnings(),visit_pitcher.getRuns());
			
			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", home_pitcher.getFullname(),
					home_pitcher.getInnings(),home_pitcher.getRuns());
			
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error msg: " +e.getMessage());
		}
	}
}
