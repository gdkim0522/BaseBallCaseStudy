package CoreJava.MainEntryPoint;

import java.io.IOException;
import java.util.Scanner;

import CoreJava.DAOClasses.FileReaderCode;
import CoreJava.Models.Game_122018;

public class MainRunner {
	String Hitters;
	String Pitchers;
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//Start Game
		Scanner input=new Scanner(System.in);
		Game_122018 ballGame=new Game_122018();
		
		try {
			//Assign Hitters and Pitchers
			//ballGame.assignHitters(1, 2, 1, 3);
			ballGame.assignHittersDAO(1, 2, 1, 3);
			
			//Get User Input
			while(true) {
				//Game Menu
				ballGame.getGameMenu();
				int result=input.nextInt();
				
				if(result<=0 || result>=10) {
					if(result==10)
						break;
					System.out.println("Invalid Data");
					continue;
				}
				
				//Record transaction and Make New Decision based on input from scanner
				//ballGame.recordTransaction(result,input);
				
				//Check if game is over
				if(ballGame.checkifGameOver())
					break;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("EX at MainRunner: " +e.getMessage());
		}
		finally {
			ballGame.savePlayers();
			ballGame.getFinalScore();
			input.close();
		}

		
		System.out.println("\nGame is over.");
	}

	static String getFiles(String fileName) {
		String line_array[]=getFiles("src/Players.csv").split("\n");
		
		int i=0;
		for(;i<line_array.length;i++) {
			if(i==0)
				continue;
			System.out.println(line_array[i]);
		}
		
		String teamVisit;
		FileReaderCode fileread=new FileReaderCode();
		teamVisit=FileReaderCode.readCsvFile(fileName);
		
		return teamVisit;
	}
}
