//package mydispatch.controller;
//
//import java.util.List;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.ModelAndView;
//
//import CoreJava.Models.Game;
//import CoreJava.Models.GameLog;
//
//@Controller
//public class ResultsController {
//
//	@RequestMapping("/test")
//	public ModelAndView resultPage(HttpServletRequest pRequest) {
//		
//		
//		System.out.println("RESULTS PAGE IS HERE");
//		
//		//HttpSession session=pRequest.getSession();
//		
//		
//		
//		//Game ballgame=(Game) session.getAttribute("ballgame");
//		
//		Game ballgame=new Game(); 
//		
//		ballgame.getScoringSummary();
//				
//		List<GameLog> gameLogs=ballgame.getGamelog_Scoring();
//
//		ModelAndView mav=new ModelAndView("results");
//		
////		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
////		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
////		mav.addObject("visit_team", ballgame.getVisit_team());
////		mav.addObject("home_team", ballgame.getHome_team());
////		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
////		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
//		mav.addObject("scoring_summary", gameLogs);		
//		
//		System.out.println("Size of list: " + gameLogs.size());
//		
//		for (GameLog gameLog : gameLogs) {
//			System.out.println(gameLog.getResult());
//		}
//		
//		//Set Session Attribute
//		//session.setAttribute("ballgame", ballgame);
//		
//		System.out.println("RESULTS PAGE HAS ENDED");
//		
//		return mav;
//		
//	}
//}
