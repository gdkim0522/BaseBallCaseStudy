package com.corejava.dao.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.DAOClasses.UserDAO;
import CoreJava.Models.User;

public class UserDAO_Test {
	
	User userExpected;	User userActual;
	UserDAO userDAOExpected;	UserDAO userDAOActual;	
	List<User> lst_users_Expected;	List<User> lst_users_Actual;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Instantiate DAO CLASS");
		userDAOActual=new UserDAO();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddUser() {
		System.out.println("TEST ADD USER BEGIN");
		
		
		
		try {
			int result=userDAOActual.addUser("Test", "test", "test@gmail.com", "test111");
			System.out.println("RESULT OF INSERT: " + result);
			
			assertTrue(result==1);
			
			result=userDAOActual.deleteUser("test@gmail.com");
			System.out.println("RESULT OF DELETION: " + result);
			
			assertTrue(result==1);
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at AddUser " + e.getMessage());
		}
		
		
		System.out.println("TEST ADD USER END");
	}

	@Test
	public void testValidateUser() {
		System.out.println("TEST VALIDATE USER BEGIN");
		
		try {
			
			userExpected=new User();
			
			userExpected.setFirstName("gene");
			userExpected.setLastName("smith");
			userExpected.setUserName("gmith");
			userExpected.setPassword("9*Gtr");
			
			userActual=userDAOActual.validateUser("gmith", "9*Gtr");

			System.out.println("OBJECTS ARE EQUAL VALUES");
			assertEquals(userExpected, userActual);

			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Validate User " + e.getMessage());
		}
		
		
		System.out.println("TEST VALIDATE USER END");
	}

}
