package com.corejava.models.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.Models.Hitter;

// TODO: Auto-generated Javadoc
/**
 * The Class Hitter_Test.
 */
public class Hitter_Test {
	
	/** The hitter expected. */
	Hitter hitter_expected;	
	/** The hitter actual. */
	Hitter hitter_actual;

	/**
	 * Sets the up before class.
	 *
	 * @throws Exception the exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - HITTER MODEL");
	}

	/**
	 * Tear down after class.
	 *
	 * @throws Exception the exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - HITTER MODEL");
	}

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		hitter_expected=new Hitter(1,1,"T. Jankowski",347,45,60,12,4,17,37,73);
		hitter_actual=new Hitter();
		
		//
		System.out.println("@Before TestSetters INTIZALIZE OBJECTS && TEST SETTERS");
		
		hitter_actual.setPlayer_id(1);
		hitter_actual.setTeam_id(1);
		hitter_actual.setFullName("T. Jankowski");
		hitter_actual.setAt_bats(347);
		hitter_actual.setRuns(45);
		hitter_actual.setHits(60);
		hitter_actual.setDoubles(12);
		hitter_actual.setHomeruns(4);
		hitter_actual.setRbi(17);
		hitter_actual.setWalks(37);
		hitter_actual.setStrikeouts(73);
		
	}

	/**
	 * Tear down.
	 *
	 * @throws Exception the exception
	 */
	@After
	public void tearDown() throws Exception {
		System.out.println("@After FINISH METHOD");
	}

	/**
	 * Test get full name.
	 */
	@Test
	public final void testGetFullName() {
		System.out.println("@Test TestGetters TEST GETTERS");
		
		
		assertTrue(hitter_expected.getFullName().equals(hitter_actual.getFullName()));
		assertTrue(hitter_expected.getAt_bats()==hitter_actual.getAt_bats());
		assertTrue(hitter_expected.getHomeruns()==hitter_actual.getHomeruns());
		assertTrue(hitter_expected.getRbi()==hitter_actual.getRbi());
		assertTrue(hitter_expected.getRuns()==hitter_actual.getRuns());
		assertTrue(hitter_expected.getHits()==hitter_actual.getHits());
		assertTrue(hitter_expected.getPlayer_id()==hitter_actual.getPlayer_id());
	}

	/**
	 * Test set full name.
	 */
	@Test
	public final void testSetFullName() {
		System.out.println("@Test EqualsObjects TEST OBJECTS ARE EQUAL");
		
		
		
		
		assertEquals(hitter_expected, hitter_actual);
	}

}
