package com.mybaseball.customAnnotations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

// TODO: Auto-generated Javadoc
/**
 * The Class PassValidator.  This validation used to make sure the password
 * has one capital, special, and number character.
 */
public class PassValidator implements ConstraintValidator<PassConstraint, String> {
	
	/** The Constant VALID_PASSWORD_REGEX. */
	public static final Pattern VALID_PASSWORD_REGEX=
			Pattern.compile("(?=.*[A-Z])(?=.*[0-9])(?=.*\\W)");
	//[A-Z]+[0-9]+\\W+
	//[A-Z0-9\W]+
	//(?=.*[A-Z])(?=.*[0-9])(?=.*\W)
	
	
	/**
	 * Validate.
	 *
	 * @param pass the pass
	 * @return true, if successful
	 */
	public static boolean validate(String pass) {
		Matcher matcher=VALID_PASSWORD_REGEX.matcher(pass);
		return matcher.find();
	}
	
	/* (non-Javadoc)
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
	 */
	public void initialize(PassConstraint arg0) {
		
	}
	
	
	/* (non-Javadoc)
	 * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
	 */
	public boolean isValid(String arg0,ConstraintValidatorContext arg1) {
		
		System.out.println(arg0);
		return (validate(arg0) && (arg0.length()>1) && (arg0.length() <8));
	}

}

