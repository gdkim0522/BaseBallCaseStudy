package com.mybaseball.customAnnotations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PassValidator implements ConstraintValidator<PassConstraint, String> {
	public static final Pattern VALID_PASSWORD_REGEX=
			Pattern.compile("(?=.*[A-Z])(?=.*[0-9])(?=.*\\W)");
	//[A-Z]+[0-9]+\\W+
	//[A-Z0-9\W]+
	//(?=.*[A-Z])(?=.*[0-9])(?=.*\W)
	
	
	public static boolean validate(String pass) {
		Matcher matcher=VALID_PASSWORD_REGEX.matcher(pass);
		return matcher.find();
	}
	
	public void initialize(PassConstraint arg0) {
		
	}
	
	
	public boolean isValid(String arg0,ConstraintValidatorContext arg1) {
		
		System.out.println(arg0);
		return (validate(arg0) && (arg0.length()>1) && (arg0.length() <8));
	}

}

