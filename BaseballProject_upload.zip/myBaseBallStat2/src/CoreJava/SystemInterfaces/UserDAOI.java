package CoreJava.SystemInterfaces;

import java.sql.SQLException;

import CoreJava.Models.User;

// TODO: Auto-generated Javadoc
/**
 * The Interface UserDAOI.
 */
public interface UserDAOI {
	
	/**
	 * The Enum SQL.
	 */
	enum SQL{
		
		/** The add user. */
		ADD_USER("INSERT INTO user_log(first_name,last_name, user_name,password) VALUES(?,?,?,?)"),
		
		/** The get user. */
		GET_USER("select * from user_log where user_name=? and password=?"),
		
		/** The delete user. */
		DELETE_USER("delete from user_log where user_name=?");
		
		/** The query. */
		private final String query;
		
		/**
		 * Instantiates a new sql.
		 *
		 * @param s the s
		 */
		private SQL(String s) {
			this.query=s;
		}
		
		/**
		 * Gets the query.
		 *
		 * @return the query
		 */
		public String getQuery() {
			return this.query;
		}
	}
	
	/**
	 * Adds the user.
	 *
	 * @param first_name the first name
	 * @param last_name the last name
	 * @param user_name the user name
	 * @param password the password
	 * @return the int
	 * @throws ClassNotFoundException the class not found exception
	 * @throws SQLException the SQL exception
	 */
	int addUser(String first_name, String last_name, String user_name, String password) throws ClassNotFoundException, SQLException;
	
	/**
	 * Validate user.
	 *
	 * @param user_name the user name
	 * @param password the password
	 * @return the user
	 * @throws ClassNotFoundException the class not found exception
	 * @throws SQLException the SQL exception
	 */
	User validateUser(String user_name, String password) throws ClassNotFoundException, SQLException;
	
	/**
	 * Delete user.
	 *
	 * @param user_name the user name
	 * @return the int
	 * @throws ClassNotFoundException the class not found exception
	 * @throws SQLException the SQL exception
	 */
	int deleteUser(String user_name) throws ClassNotFoundException, SQLException;
}
