package CoreJava.SystemInterfaces;

import java.sql.SQLException;

import CoreJava.Models.User;

public interface UserDAOI {
	enum SQL{
		ADD_USER("INSERT INTO user_log(first_name,last_name, user_name,password) VALUES(?,?,?,?)"),
		GET_USER("select * from user_log where user_name=? and password=?"),
		DELETE_USER("delete from user_log where user_name=?");
		
		private final String query;
		
		private SQL(String s) {
			this.query=s;
		}
		
		public String getQuery() {
			return this.query;
		}
	}
	
	int addUser(String first_name, String last_name, String user_name, String password) throws ClassNotFoundException, SQLException;
	
	User validateUser(String user_name, String password) throws ClassNotFoundException, SQLException;
	
	int deleteUser(String user_name) throws ClassNotFoundException, SQLException;
}
