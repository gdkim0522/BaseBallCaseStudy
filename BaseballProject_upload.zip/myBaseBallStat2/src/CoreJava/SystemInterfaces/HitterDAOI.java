package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Hitter;

// TODO: Auto-generated Javadoc
/**
 * The Interface HitterDAOI.
 */
public interface HitterDAOI {
	
	/**
	 * The Enum SQL.
	 */
	enum SQL{
		
		/** The get hitter by id. */
		GET_HITTER_BY_ID("select * from player where player_id=?"),
		
		/** The get all hitters by team id. */
		GET_ALL_HITTERS_BY_TEAM_ID("select * from player where team_id=?");
		
		/** The query. */
		private final String query;
		
		/**
		 * Instantiates a new sql.
		 *
		 * @param query the query
		 */
		private SQL(String query) {
			this.query=query;
		}
		
		/**
		 * Gets the query.
		 *
		 * @return the query
		 */
		public String getQuery() {
			return this.query;
		}
	}
	
	/**
	 * Gets the all hitters by team ID.
	 *
	 * @param team_id the team id
	 * @return the all hitters by team ID
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	List<Hitter> getAllHittersByTeamID(int team_id) throws SQLException, ClassNotFoundException, IOException;
	
	/**
	 * Gets the hitterer by ID.
	 *
	 * @param player_id the player id
	 * @return the hitterer by ID
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	Hitter getHittererByID(int player_id) throws SQLException, ClassNotFoundException, IOException;
}
