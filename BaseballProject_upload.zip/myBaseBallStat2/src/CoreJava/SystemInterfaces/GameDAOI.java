package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.GameLog;


// TODO: Auto-generated Javadoc
/**
 * The Interface GameDAOI.
 */
public interface GameDAOI {
	
	/**
	 * The Enum SQL.
	 */
	public enum SQL{
		
		/** The add gamelog. */
		ADD_GAMELOG("INSERT INTO gamelog(play_series,current_Play, current_result,inning,is_top,balls,strikes,outs,visit_runs,home_runs"
				+ ",hitter_id,pitcher_id,score_Updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)"),
		
		/** The get gamelog score. */
		GET_GAMELOG_SCORE("select * from gamelog where score_updated=? order by play_series"),
		
		/** The get gamelog current. */
		GET_GAMELOG_CURRENT("select * from gamelog where hitter_id=? and play_series>? order by play_series"),
		
		/** The get gamelog currenthitter. */
		GET_GAMELOG_CURRENTHITTER("select * from gamelog where hitter_id=? order by play_series"),
		
		/** The truncate table gamelog. */
		TRUNCATE_TABLE_GAMELOG("Truncate table gamelog");
		
		/** The query. */
		private final String query;
		
		/**
		 * Instantiates a new sql.
		 *
		 * @param query the query
		 */
		private SQL(String query) {
			this.query=query;			
		}
		
		/**
		 * Gets the query.
		 *
		 * @return the query
		 */
		public String getQuery() {
			return this.query;
		}
		
	}
	
	/**
	 * Adds the game log.
	 *
	 * @param playlog the playlog
	 * @param current_play the current play
	 * @param result the result
	 * @param inning the inning
	 * @param top the top
	 * @param balls the balls
	 * @param strikes the strikes
	 * @param outs the outs
	 * @param visit_runs the visit runs
	 * @param home_runs the home runs
	 * @param hitter_id the hitter id
	 * @param pitcher_id the pitcher id
	 * @param score_updated the score updated
	 * @return the int
	 * @throws ClassNotFoundException the class not found exception
	 * @throws SQLException the SQL exception
	 */
	int addGameLog(int playlog,int current_play, String result, int inning, boolean top, int balls, int strikes,
			int outs, int visit_runs, int home_runs, int hitter_id, int pitcher_id, boolean score_updated) throws ClassNotFoundException, SQLException;
	
	/**
	 * Gets the game log score.
	 *
	 * @param scoreupdated the scoreupdated
	 * @return the game log score
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	List<GameLog> getGameLogScore(String scoreupdated) throws ClassNotFoundException, IOException,SQLException;

	/**
	 * Gets the game log current.
	 *
	 * @param hitter_id the hitter id
	 * @param play_series the play series
	 * @return the game log current
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	List<GameLog> getGameLogCurrent(int hitter_id, int play_series) throws ClassNotFoundException, IOException,SQLException;
	
	/**
	 * Gets the game log current hitter.
	 *
	 * @param hitter_id the hitter id
	 * @return the game log current hitter
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	List<GameLog> getGameLogCurrentHitter(int hitter_id) throws ClassNotFoundException, IOException,SQLException;
	
	/**
	 * Truncate game log.
	 *
	 * @return the int
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	int truncateGameLog()  throws ClassNotFoundException, IOException,SQLException;
}
