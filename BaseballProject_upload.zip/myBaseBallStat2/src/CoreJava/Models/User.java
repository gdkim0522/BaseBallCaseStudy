package CoreJava.Models;

import org.hibernate.validator.constraints.NotEmpty;

import com.mybaseball.customAnnotations.PassConstraint;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the User class which holds all the relevant data for each user. 
 * 
 * @author Greg Kim
 *
 */


public class User {
	
	/** The first name. */
	@NotEmpty(message = "FirstName may not be empty")	
	private String firstName;
	
	/** The last name. */
	@NotEmpty(message = "LastName may not be empty")
	private String lastName;
	
	/** The user name. */
	@NotEmpty(message = "UserName may not be empty")
	private String userName;
	
	/** The gender. */
	private String gender;
	
	/** The password. */
	@PassConstraint
	private String password;

	
	/**
	 * Instantiates a new user.
	 */
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object object) {
		if(object instanceof User) {
			User other=(User) object;
			boolean SameFirstName=this.firstName.equals(other.getFirstName());
			boolean SameLastName=this.lastName.equals(other.getLastName());
			boolean SameUserName=this.userName.equals(other.getUserName());
			boolean SamePassword=this.password.equals(other.getPassword());
			
			if(SameFirstName && SameLastName && SameUserName && SamePassword)
				return true;
			else
				return false;
		}else
			return false;
	}
	
	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	/**
	 * Gets the gender.
	 *
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	
	/**
	 * Sets the gender.
	 *
	 * @param gender the new gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
}
