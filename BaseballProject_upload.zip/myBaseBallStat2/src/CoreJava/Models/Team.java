package CoreJava.Models;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the Team class which holds all the relevant data for each team. 
 * 
 * @author Greg Kim
 *
 */


public class Team {
	
	/** The team id. */
	int team_id;
	
	/** The team name. */
	String team_name;
	
	/** The city. */
	String city="Black";
	
	/** The color. */
	String color;
	
	/** The Stadium. */
	String Stadium;
	
	/** The gb. */
	int gb;
	
	/** The wins. */
	int wins;
	
	/** The losses. */
	int losses;

	
	/**
	 * Instantiates a new team.
	 *
	 * @param team_id the team id
	 * @param team_name the team name
	 * @param city the city
	 * @param color the color
	 * @param stadium the stadium
	 * @param wins the wins
	 * @param losses the losses
	 */
	public Team(int team_id, String team_name, String city, String color, String stadium, int wins, int losses) {
		this.team_id = team_id;
		this.team_name = team_name;
		this.city = city;
		this.color = "Black";
		this.Stadium = stadium;
		this.wins = wins;
		this.losses = losses;
	}
	
	/**
	 * Instantiates a new team.
	 */
	public Team() {
		// TODO Auto-generated constructor stub
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object object) {
		if(object instanceof Team) {
			Team other=(Team) object;
			boolean SameId=(this.team_id==other.getTeam_id());
			boolean SameName=this.team_name.equals(other.getTeam_name());
			boolean SameCity=this.city.equals(other.getCity());
			boolean SameColor=this.color.equals(other.getColor());
			boolean SameStadium=this.Stadium.equals(other.getStadium());
			boolean SameWins=(this.wins==other.getWins());
			boolean SameLosses=(this.losses==other.getLosses());
			
			if(SameId && SameName && SameCity && SameColor && SameStadium && SameWins && SameLosses)
				return true;
			else
				return false;
			
		}else
			return false;
		
	}


	/**
	 * Gets the team id.
	 *
	 * @return the team id
	 */
	public int getTeam_id() {
		return team_id;
	}
	
	/**
	 * Sets the team id.
	 *
	 * @param team_id the new team id
	 */
	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}
	
	/**
	 * Gets the team name.
	 *
	 * @return the team name
	 */
	public String getTeam_name() {
		return team_name;
	}
	
	/**
	 * Sets the team name.
	 *
	 * @param team_name the new team name
	 */
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	
	/**
	 * Gets the wins.
	 *
	 * @return the wins
	 */
	public int getWins() {
		return wins;
	}
	
	/**
	 * Sets the wins.
	 *
	 * @param wins the new wins
	 */
	public void setWins(int wins) {
		this.wins = wins;
	}
	
	/**
	 * Gets the losses.
	 *
	 * @return the losses
	 */
	public int getLosses() {
		return losses;
	}
	
	/**
	 * Sets the losses.
	 *
	 * @param losses the new losses
	 */
	public void setLosses(int losses) {
		this.losses = losses;
	}
	
	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}
//	public String getManager() {
//		return Manager;
//	}
//	public void setManager(String manager) {
//		Manager = manager;
/**
 * Gets the color.
 *
 * @return the color
 */
//	}
	public String getColor() {
		return color;
	}
	
	/**
	 * Sets the color.
	 *
	 * @param color the new color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	
	/**
	 * Gets the stadium.
	 *
	 * @return the stadium
	 */
	public String getStadium() {
		return Stadium;
	}
	
	/**
	 * Sets the stadium.
	 *
	 * @param stadium the new stadium
	 */
	public void setStadium(String stadium) {
		this.Stadium = stadium;
	}

	/**
	 * Gets the gb.
	 *
	 * @return the gb
	 */
	public int getGb() {
		return gb;
	}

	/**
	 * Sets the gb.
	 *
	 * @param gb the new gb
	 */
	public void setGb(int gb) {
		this.gb = gb;
	}
	
	
	
	
}
