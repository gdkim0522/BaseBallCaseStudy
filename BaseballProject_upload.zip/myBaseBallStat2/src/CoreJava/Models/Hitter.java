package CoreJava.Models;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the Hitter class which holds all the relevant data for each hitter. 
 * 
 * @author Greg Kim
 *
 */


public class Hitter extends Player {

	/**
	 * Instantiates a new hitter.
	 *
	 * @param player_id the player id
	 * @param team_id the team id
	 * @param fullName the full name
	 * @param at_bats the at bats
	 * @param runs the runs
	 * @param hits the hits
	 * @param doubles the doubles
	 * @param homeruns the homeruns
	 * @param rbi the rbi
	 * @param walks the walks
	 * @param strikeouts the strikeouts
	 */
	public Hitter(int player_id, int team_id, String fullName, int at_bats, int runs, int hits, int doubles,
			int homeruns,int rbi, int walks, int strikeouts) {
		super(player_id, team_id, fullName, at_bats, runs, hits, doubles, homeruns,rbi, 
				walks, strikeouts);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Instantiates a new hitter.
	 */
	public Hitter() {
		// TODO Auto-generated constructor stub
	}


	
}
