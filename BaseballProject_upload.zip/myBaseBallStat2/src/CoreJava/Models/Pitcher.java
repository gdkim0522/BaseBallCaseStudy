package CoreJava.Models;

// TODO: Auto-generated Javadoc
/**
 * 
 * This is the Pitcher class which holds all the relevant data for each pitcher. 
 * 
 * @author Greg Kim
 *
 */



public class Pitcher{
	
	/** The pitcher id. */
	int pitcher_id;
	
	/** The team id. */
	int team_id;
	
	/** The fullname. */
	String fullname;
	
	/** The wins. */
	int wins;
	
	/** The losses. */
	int losses;
	
	/** The innings. */
	float innings;
	
	/** The runs. */
	int runs;
	
	/** The hits. */
	int hits;
	
	/** The walks. */
	int walks;
	
	/** The strikeouts. */
	int strikeouts;
	
	
	/**
	 * Instantiates a new pitcher.
	 *
	 * @param pitcher_id the pitcher id
	 * @param team_id the team id
	 * @param fullname the fullname
	 * @param wins the wins
	 * @param losses the losses
	 * @param innings the innings
	 * @param hits the hits
	 * @param runs the runs
	 * @param walks the walks
	 * @param strikeouts the strikeouts
	 */
	public Pitcher(int pitcher_id, int team_id, String fullname, int wins, int losses, float innings, 
			int hits, int runs, int walks, int strikeouts) {
		this.pitcher_id = pitcher_id;
		this.team_id = team_id;
		this.fullname = fullname;
		this.wins = wins;
		this.losses = losses;
		this.innings = innings;
		this.hits = hits;
		this.runs = runs;
		this.walks = walks;
		this.strikeouts = strikeouts;
	}
	
	
	/**
	 * Instantiates a new pitcher.
	 */
	public Pitcher() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object object) {
		if(object instanceof Pitcher) {
			Pitcher other=(Pitcher) object;
			boolean SamePitcherId=(this.pitcher_id==other.getPitcher_id());
			boolean SameTeamId=(this.team_id==other.getTeam_id());
			boolean SameName=this.fullname.equals(other.getFullname());
			boolean SameWins=(this.wins==other.getWins());
			boolean SameLosses=(this.losses==other.getLosses());
			boolean SameInnings=(this.innings==other.getInnings());			
			boolean SameRuns=(this.runs==other.getRuns());
			boolean SameHits=(this.hits==other.getHits());
			boolean SameWalks=(this.walks==other.getWalks());
			boolean SameSO=(this.strikeouts==other.getStrikeouts());
			
			if(SamePitcherId && SameTeamId && SameName && SameWins && SameLosses && SameInnings && 
					SameRuns && SameHits && SameWalks && SameSO)
				return true;
			else
				return false;
			
		}else
			return false;
	}	
	
	/**
	 * Gets the pitcher id.
	 *
	 * @return the pitcher id
	 */
	public int getPitcher_id() {
		return pitcher_id;
	}
	
	/**
	 * Sets the pitcher id.
	 *
	 * @param pitcher_id the new pitcher id
	 */
	public void setPitcher_id(int pitcher_id) {
		this.pitcher_id = pitcher_id;
	}
	
	/**
	 * Gets the fullname.
	 *
	 * @return the fullname
	 */
	public String getFullname() {
		return this.fullname;
	}
	
	/**
	 * Sets the fullname.
	 *
	 * @param fullname the new fullname
	 */
	public void setFullname(String fullname) {
		this.fullname= fullname;
	}
	
	/**
	 * Gets the innings.
	 *
	 * @return the innings
	 */
	public float getInnings() {
		return innings;
	}
	
	/**
	 * Sets the innings.
	 *
	 * @param innings the new innings
	 */
	public void setInnings(float innings) {
		this.innings = innings;
	}
	
	/**
	 * Gets the runs.
	 *
	 * @return the runs
	 */
	public int getRuns() {
		return runs;
	}
	
	/**
	 * Sets the runs.
	 *
	 * @param runs the new runs
	 */
	public void setRuns(int runs) {
		this.runs = runs;
	}
	
	/**
	 * Gets the walks.
	 *
	 * @return the walks
	 */
	public int getWalks() {
		return walks;
	}
	
	/**
	 * Sets the walks.
	 *
	 * @param walks the new walks
	 */
	public void setWalks(int walks) {
		this.walks = walks;
	}
	
	/**
	 * Gets the strikeouts.
	 *
	 * @return the strikeouts
	 */
	public int getStrikeouts() {
		return strikeouts;
	}
	
	/**
	 * Sets the strikeouts.
	 *
	 * @param strikeouts the new strikeouts
	 */
	public void setStrikeouts(int strikeouts) {
		this.strikeouts = strikeouts;
	}
	
	/**
	 * Gets the team id.
	 *
	 * @return the team id
	 */
	public int getTeam_id() {
		return team_id;
	}
	
	/**
	 * Sets the team id.
	 *
	 * @param team_id the new team id
	 */
	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}
	
	/**
	 * Gets the wins.
	 *
	 * @return the wins
	 */
	public int getWins() {
		return wins;
	}
	
	/**
	 * Sets the wins.
	 *
	 * @param wins the new wins
	 */
	public void setWins(int wins) {
		this.wins = wins;
	}
	
	/**
	 * Gets the losses.
	 *
	 * @return the losses
	 */
	public int getLosses() {
		return losses;
	}
	
	/**
	 * Sets the losses.
	 *
	 * @param losses the new losses
	 */
	public void setLosses(int losses) {
		this.losses = losses;
	}
	
	/**
	 * Gets the hits.
	 *
	 * @return the hits
	 */
	public int getHits() {
		return hits;
	}
	
	/**
	 * Sets the hits.
	 *
	 * @param hits the new hits
	 */
	public void setHits(int hits) {
		this.hits = hits;
	}
	
	
	
}
