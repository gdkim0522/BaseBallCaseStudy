package CoreJava.Models;

/**
 * 
 * This is the Pitcher class which holds all the relevant data for each pitcher. 
 * 
 * @author Greg Kim
 *
 */



public class Pitcher{
	int pitcher_id;
	int team_id;
	String fullname;
	int wins;
	int losses;
	float innings;
	int runs;
	int hits;
	int walks;
	int strikeouts;
	
	
	public Pitcher(int pitcher_id, int team_id, String fullname, int wins, int losses, float innings, 
			int hits, int runs, int walks, int strikeouts) {
		this.pitcher_id = pitcher_id;
		this.team_id = team_id;
		this.fullname = fullname;
		this.wins = wins;
		this.losses = losses;
		this.innings = innings;
		this.hits = hits;
		this.runs = runs;
		this.walks = walks;
		this.strikeouts = strikeouts;
	}
	
	
	public Pitcher() {
		// TODO Auto-generated constructor stub
	}

	public boolean equals(Object object) {
		if(object instanceof Pitcher) {
			Pitcher other=(Pitcher) object;
			boolean SamePitcherId=(this.pitcher_id==other.getPitcher_id());
			boolean SameTeamId=(this.team_id==other.getTeam_id());
			boolean SameName=this.fullname.equals(other.getFullname());
			boolean SameWins=(this.wins==other.getWins());
			boolean SameLosses=(this.losses==other.getLosses());
			boolean SameInnings=(this.innings==other.getInnings());			
			boolean SameRuns=(this.runs==other.getRuns());
			boolean SameHits=(this.hits==other.getHits());
			boolean SameWalks=(this.walks==other.getWalks());
			boolean SameSO=(this.strikeouts==other.getStrikeouts());
			
			if(SamePitcherId && SameTeamId && SameName && SameWins && SameLosses && SameInnings && 
					SameRuns && SameHits && SameWalks && SameSO)
				return true;
			else
				return false;
			
		}else
			return false;
	}	
	
	public int getPitcher_id() {
		return pitcher_id;
	}
	public void setPitcher_id(int pitcher_id) {
		this.pitcher_id = pitcher_id;
	}
	
	public String getFullname() {
		return this.fullname;
	}
	public void setFullname(String fullname) {
		this.fullname= fullname;
	}
	
	public float getInnings() {
		return innings;
	}
	public void setInnings(float innings) {
		this.innings = innings;
	}
	public int getRuns() {
		return runs;
	}
	public void setRuns(int runs) {
		this.runs = runs;
	}
	public int getWalks() {
		return walks;
	}
	public void setWalks(int walks) {
		this.walks = walks;
	}
	public int getStrikeouts() {
		return strikeouts;
	}
	public void setStrikeouts(int strikeouts) {
		this.strikeouts = strikeouts;
	}
	public int getTeam_id() {
		return team_id;
	}
	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}
	public int getWins() {
		return wins;
	}
	public void setWins(int wins) {
		this.wins = wins;
	}
	public int getLosses() {
		return losses;
	}
	public void setLosses(int losses) {
		this.losses = losses;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	
	
	
}
