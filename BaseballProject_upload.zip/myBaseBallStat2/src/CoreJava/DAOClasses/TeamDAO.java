package CoreJava.DAOClasses;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import CoreJava.DAO.OracleConnection;
import CoreJava.Models.Team;

import CoreJava.SystemInterfaces.TeamDAOI;

// TODO: Auto-generated Javadoc
/**
 * The Class TeamDAO.
 *
 * @author Greg Kim
 * 
 *  <div>
 *  	Access Team Information.
 *  </div>
 */

public class TeamDAO extends AbstractDAO implements TeamDAOI {
	
	/** The teams. */
	List<Team> teams=new LinkedList<Team>();
	
	/** The method. */
	String method="TeamDAO - ";
	
	
	/**
	 * Instantiates a new team DAO.
	 */
	public TeamDAO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *  
	 *  	 <div>
	 *  	Get a Team object based on a team_id.
	 *  	</div>.
	 *
	 * @param team_id the team id
	 * @return the team by id
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */


	@Override
	public Team getTeamById(int team_id) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Team team=null;
		
		try
		{ 
			this.connect();
						
			ps=conn.prepareStatement(SQL.GET_TEAM_BY_ID.getQuery());
			ps.setInt(1, team_id);
			rs=ps.executeQuery();  
					  
			if(rs.next()) {
				team=new Team();
				
				team.setTeam_id(rs.getInt(1));
				team.setTeam_name(rs.getString(2));
				team.setCity(rs.getString(3));
				team.setStadium(rs.getString(4));
				team.setWins(rs.getInt(5));
				team.setLosses(rs.getInt(6));
				
//				student.setStudent_id();
//				student.setFull_name(rs.getString(2));
//				student.setEmail(rs.getString(3));
//				student.setGpa(rs.getDouble(4));
//				student.setPass(rs.getString(5));
//				student.setStudent_role(rs.getInt(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
		}finally {
			dispose();
		}
		
		return team;
	}


	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.TeamDAOI#getAllTeams()
	 */
	/* 
	 * Get all baseball teams to a list from a database
	 */
	@Override
	public List<Team> getAllTeams() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Team team=null;
		
		
		try
		{ 
		  this.connect();

		  ps = conn.prepareStatement(SQL.GET_ALL_TEAMS.getQuery());  
		  rs=ps.executeQuery();  

		  while(rs.next()) {
				team=new Team();
				
				team.setTeam_id(rs.getInt(1));
				team.setTeam_name(rs.getString(2));
				team.setCity(rs.getString(3));
				team.setStadium(rs.getString(4));
				team.setWins(rs.getInt(5));
				team.setLosses(rs.getInt(6));
				
				teams.add(team);
		  }
		  
		  return teams;
		  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(EXSQL + e.getMessage());
			//e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
		}finally {
			dispose();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.TeamDAOI#getTeamStandings()
	 */
	/* 
	 *  Return a list of the teams based on standings.
	 */
	@Override
	public List<Team> getTeamStandings() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Team team=null;
		
		teams.clear();
		
		try
		{ 
		  this.connect();

		  ps = conn.prepareStatement(SQL.GET_TEAM_STANDINGS.getQuery());  
		  rs=ps.executeQuery();  

		  int i=1;
		  
		  int wins=0;
		  
		  
		  while(rs.next()) {
				team=new Team();
				
				team.setTeam_id(rs.getInt(1));
				team.setTeam_name(rs.getString(2));
				team.setCity(rs.getString(3));
				
				if(i==1) {
					//team.setStadium("-");
					//team.setTeam_id(0);
					wins=rs.getInt(5);}
				else {
					int gb=wins-rs.getInt(5);
					team.setGb(gb);
				}
					
				team.setWins(rs.getInt(5));
				team.setLosses(rs.getInt(6));
				
				teams.add(team);
				
				
				i++;
		  }
		  
		  return teams;
		  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(EXSQL + e.getMessage());
			//e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
		}finally {
			dispose();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.TeamDAOI#updateTeamWins(int)
	 */
	@Override
	public int updateTeamWins(int team_id) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		method="TeamDAO - ";
		method=method.concat("updateTeamWins() - ");				
		int result=0;
		
		try
		{ 
			//Assign course_id and student_id
			connect();
			
			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
			
			ps=conn.prepareStatement(SQL.UPDATE_TEAM_WINS.getQuery());

  			//Run Insert
  			ps.setInt(1, team_id);
  			result= ps.executeUpdate();
  			ps.close();
  			conn.close();
  			
  			if(result==1)
  				return 1;
  			else
  				return -100;
  			

  			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.TeamDAOI#updateTeamLosses(int)
	 */
	@Override
	public int updateTeamLosses(int team_id) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		method="TeamDAO - ";
		method=method.concat("updateTeamLosses() - ");				
		int result=0;
		
		try
		{ 
			//Assign course_id and student_id
			connect();
			
			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
			
			ps=conn.prepareStatement(SQL.UPDATE_TEAM_LOSSES.getQuery());

  			//Run Insert
  			ps.setInt(1, team_id);
  			result= ps.executeUpdate();
  			
  			ps.close();
  			conn.close();
  			
  			if(result==1)
  				return 1;
  			else
  				return -100;
  			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}
}
