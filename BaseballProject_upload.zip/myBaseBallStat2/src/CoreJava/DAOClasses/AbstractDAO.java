package CoreJava.DAOClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CoreJava.DAO.OracleConnection;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractDAO.
 *
 * @author Greg Kim
 * <div>
 * Abstract Class extended by the Five DAO Classes. It has a connect and dispose methods to
 * connect to the Oracle Database.</div>
 */

public abstract class AbstractDAO {
	
	/** The conn. */
	protected Connection conn=null;
	
	/** The ps. */
	protected PreparedStatement ps=null;
	
	/** The st. */
	protected Statement st=null;
	
	/** The rs. */
	protected ResultSet rs=null;
	
	/** The sql. */
	protected String sql=null;
	
	/** The ex. */
	protected String EX="EXCEPTION ERROR: ";
	
	/** The exsql. */
	protected String EXSQL="SQLEXCEPTION ERROR: ";
	
	/** The exclass. */
	protected String EXCLASS="CLASSEXCEPTION ERROR: ";
	
	/** The exio. */
	protected String EXIO="IOEXCEPTION ERROR: ";
	
	/** The abstract. */
	protected String ABSTRACT="ABSTRACT - ";
	
	/**
	 * <div>
	 * 	  Connect to the database resources
	 * 	 
	 * 	 </div>.
	 */
	public void connect() {
		String Method="connect() -";

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			OracleConnection oracleConnection=new OracleConnection(); 
			conn = oracleConnection.getConnection(); 
		}  catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(Method + ABSTRACT+EXCLASS + e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(Method + ABSTRACT+EXSQL +e.getMessage());
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(Method + ABSTRACT+EX + e.getMessage());
		}
	}
	
	/**
	 * 	 <div>Clean up the resources</div>.
	 */
	public void dispose() {
		String Method="dispose() -";
		try {
			if(!rs.equals(null)) {
				if(!rs.isClosed())rs.close();
			}
			
			if(!ps.equals(null)) {
				if(!ps.isClosed()) ps.close();
			}
			
			if(!conn.equals(null)) {
				if(!conn.isClosed()) conn.close();
			}
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println(Method+ABSTRACT+EXSQL +e.getMessage());
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(Method+ABSTRACT+EX + e.getMessage());
		}
	}
}
