package CoreJava.DAOClasses;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import CoreJava.Models.Pitcher;
import CoreJava.SystemInterfaces.PitcherDAOI;

// TODO: Auto-generated Javadoc
/**
 * The Class PitcherDAO.
 *
 * @author Greg Kim
 * 
 * <div>
 * Access a team pitchers information from database.
 * </div>
 */

public class PitcherDAO extends AbstractDAO implements PitcherDAOI{
	
	/** The pitchers. */
	List<Pitcher> pitchers=new LinkedList<Pitcher>();

	/**
	 * Instantiates a new pitcher DAO.
	 */
	public PitcherDAO() {
	}
	
	
	/**
	 * Return a pitcher on a team based on team_id and player_id.
	 *
	 * @param team_id the team id
	 * @param player_id the player id
	 * @return the pitcher by ID
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public Pitcher getPitcherByID(int team_id, int player_id) throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		try
		{
			this.connect();
			ps=conn.prepareStatement(SQL.GET_PITCHER_BY_ID.getQuery());
			ps.setInt(1, team_id);
			ps.setInt(2, player_id);
			rs=ps.executeQuery();
			
			
			while(rs.next()) {
				int pitcher_id=rs.getInt(1);
				int teamid=rs.getInt(2);
				String playerName=rs.getString(3);
				int wins=rs.getInt(4);
				int losses=rs.getInt(5);
				int innings=rs.getInt(6);
				int hits=rs.getInt(7);
				int runs=rs.getInt(8);			
				int walks=rs.getInt(9);
				int strikeouts=rs.getInt(10);
				
				return new Pitcher(pitcher_id, team_id, playerName, wins, losses, innings, hits, runs, walks, strikeouts);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
			
		}finally {
			dispose();
		}
		return null;
	}



	/**
	 * Return pitchers on a team based on team_id.
	 *
	 * @param team_id the team id
	 * @return the pitcher by team ID
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	@Override
	public List<Pitcher> getPitcherByTeamID(int team_id) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		
		pitchers.clear();
		try
		{
			this.connect();
			ps=conn.prepareStatement(SQL.GET_PITCHERS_BY_TEAMID.getQuery());
			ps.setInt(1, team_id);
			rs=ps.executeQuery();
			
			
			while(rs.next()) {
				int pitcher_id=rs.getInt(1);
				int teamid=rs.getInt(2);
				String playerName=rs.getString(3);
				int wins=rs.getInt(4);
				int losses=rs.getInt(5);
				int innings=rs.getInt(6);
				int hits=rs.getInt(7);
				int runs=rs.getInt(8);			
				int walks=rs.getInt(9);
				int strikeouts=rs.getInt(10);
				
				pitchers.add(new Pitcher(pitcher_id, team_id, playerName, wins, losses, innings, hits, runs, walks, strikeouts));
			}
			
			return pitchers;			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
			
		}finally {
			dispose();
		}
		return null;
	}

}
