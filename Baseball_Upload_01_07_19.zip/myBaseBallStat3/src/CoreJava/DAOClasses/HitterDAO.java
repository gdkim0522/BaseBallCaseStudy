package CoreJava.DAOClasses;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import CoreJava.DAO.OracleConnection;
import CoreJava.Models.Hitter;
import CoreJava.SystemInterfaces.HitterDAOI;
import CoreJava.SystemInterfaces.GameDAOI.SQL;

/**
 * 
 * @author Greg Kim
 *
<div>
Access a team hitters information from database.
</div>
 */

public class HitterDAO extends AbstractDAO implements HitterDAOI{
	List<Hitter> hitters=new LinkedList<Hitter>();
	String method="HitterDAO - ";

	public HitterDAO() {
		// TODO Auto-generated constructor stub
		//hitters
	}
	
	
	
	/**
	 * Return a hitter on a team based on team_id and player_id
	 * @param email
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	@Override
	public Hitter getHittererByID(int player_id) throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		try
		{
			this.connect();
			ps=conn.prepareStatement(SQL.GET_HITTER_BY_ID.getQuery());
			ps.setInt(1, player_id);
			rs=ps.executeQuery();
			
			
			while(rs.next()) {
				int playerId=rs.getInt(1);
				int teamId=rs.getInt(2);
				String playerName=rs.getString(3);
				int atBats=rs.getInt(4);
				int runs=rs.getInt(5);
				int hits=rs.getInt(6);
				int doubles=rs.getInt(7);
				int homeRuns=rs.getInt(8);
				int rbi=rs.getInt(9);			
				int walks=rs.getInt(10);
				int strikeouts=rs.getInt(11);
				
				
				return new Hitter(playerId, teamId, playerName, atBats, runs, hits, doubles, homeRuns, rbi, walks,strikeouts);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
			
		}finally {
			dispose();
		}
		return null;
	}
	
	
	
	
	
	
	
	
	/**
	 * Return all hitters on a team based on team_id
	 * @param email
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	@Override
	public List<Hitter> getAllHittersByTeamID(int team_id) throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		try
		{
			this.connect();
			hitters.clear();
			ps=conn.prepareStatement(SQL.GET_ALL_HITTERS_BY_TEAM_ID.getQuery());
			ps.setInt(1, team_id);
			rs=ps.executeQuery();
			
			
			while(rs.next()) {
				int playerId=rs.getInt(1);
				int teamId=rs.getInt(2);
				String playerName=rs.getString(3);
				int atBats=rs.getInt(4);
				int runs=rs.getInt(5);
				int hits=rs.getInt(6);
				int doubles=rs.getInt(7);
				int homeRuns=rs.getInt(8);
				int rbi=rs.getInt(9);			
				int walks=rs.getInt(10);
				int strikeouts=rs.getInt(11);
				
				hitters.add(new Hitter(playerId, teamId, 
						playerName, atBats, runs, hits, doubles, 
						homeRuns, rbi, walks,strikeouts));
			}
			
				return hitters;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
			
		}finally {
			dispose();
		}
		return null;
	}


	/**
	 * 
	 */
	
	@Override
	public int updateHitterStats(int at_bats, int runs, int hits, int doubles, int home_runs, int rbi, int walks,
			int strikeouts, int player_id) throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		
		method="HitterDAO - ";
		method=method.concat("updateHitterStats() - ");				
		int result=0;
		
		try
		{ 
			//Assign course_id and student_id
			connect();
			
			System.out.println("At_bats " + at_bats);
			System.out.println("Hits " + hits);
			System.out.println("Player_ID " + player_id);
			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
			
			ps=conn.prepareStatement(SQL.UPDATE_HITTER_STAT.getQuery());

  			//Run Insert
  			ps.setInt(1, at_bats);
  			ps.setInt(2, runs);
  			ps.setInt(3, hits);
  			ps.setInt(4, doubles);
  			ps.setInt(5, home_runs);
  			ps.setInt(6, rbi);
  			ps.setInt(7, walks);
  			ps.setInt(8, strikeouts);
  			ps.setInt(9, player_id);
  			
  			result= ps.executeUpdate();
  			ps.close();
  			conn.close();
  			System.out.println("Result of Update: " + result);
  			if(result==1)
  				return 1;
  			else
  				return -100;
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

}
