package CoreJava.Models;


/**
 * 
 * This is the Player class which holds all the relevant data for each game transaction player. 
 * 
 * @author Greg Kim
 *
 */



public class Player {
	int player_id;
	int team_id;
	String fullName;
	int at_bats;
	int hits;
	int runs;
	int doubles;
	int homeruns;
	int rbi;
	int walks;
	int strikeouts;
	Player todayStats;

	public Player() {
		// TODO Auto-generated constructor stub
	}
	
	public Player(int player_id, int team_id, String fullName, int at_bats, int runs, int hits, int doubles,
			int homeruns, Integer rbi,int walks, int strikeouts) {
		this.player_id = player_id;
		this.team_id = team_id;
		this.fullName = fullName;
		this.at_bats = at_bats;
		this.runs = runs;
		this.hits = hits;
		this.doubles = doubles;
		this.homeruns = homeruns;
		this.rbi=rbi;
		this.walks = walks;
		this.strikeouts = strikeouts;
		this.todayStats=new Player();
	}
	
	
	
	public boolean equals(Object object) {
		if(object instanceof Hitter) {
			Hitter other=(Hitter) object;
			boolean SamePlayerId=(this.player_id ==other.getPlayer_id());
			boolean SameTeamId=(this.team_id==other.getTeam_id());
			boolean SameName=this.fullName.equals(other.getFullName());
			boolean SameAtBats=(this.at_bats==other.getAt_bats());
			boolean SameHits=(this.hits==other.getHits());
			boolean SameRuns=(this.runs==other.getRuns());
			boolean SameDoubles=(this.doubles==other.getDoubles());
			boolean SameHR=(this.homeruns==other.getHomeruns());
			boolean SameRBI=(this.rbi==other.getRbi());
			boolean SameWalks=(this.walks==other.getWalks());
			boolean SameSO=(this.strikeouts==other.getStrikeouts());
			
			if(SamePlayerId && SameTeamId && SameName && SameAtBats && SameHits && SameRuns && SameDoubles && SameHR
					&& SameRBI && SameWalks && SameSO)
				return true;
			else
				return false;
			
		}else
			return false;
		
	}
	

	public int getPlayer_id() {
		return player_id;
	}
	public void setPlayer_id(int player_id) {
		this.player_id = player_id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	} 
	
	public int getAt_bats() {
		return at_bats;
	}
	public void setAt_bats(int at_bats) {
		this.at_bats = at_bats;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public int getDoubles() {
		return doubles;
	}
	public void setDoubles(int doubles) {
		this.doubles = doubles;
	}
	public int getHomeruns() {
		return homeruns;
	}
	public void setHomeruns(int homeruns) {
		this.homeruns = homeruns;
	}
	public int getWalks() {
		return walks;
	}
	public void setWalks(int walks) {
		this.walks = walks;
	}
	public int getStrikeouts() {
		return strikeouts;
	}
	public void setStrikeouts(int strikeouts) {
		this.strikeouts = strikeouts;
	}


	public int getTeam_id() {
		return team_id;
	}


	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}


	public int getRuns() {
		return runs;
	}


	public void setRuns(int runs) {
		this.runs = runs;
	}


	public int getRbi() {
		return rbi;
	}


	public void setRbi(int rbi) {
		this.rbi = rbi;
	}


	public Player getTodayStats() {
		return todayStats;
	}

	public void setTodayStats(Player todayStats) {
		this.todayStats = todayStats;
	}

	
	
}
