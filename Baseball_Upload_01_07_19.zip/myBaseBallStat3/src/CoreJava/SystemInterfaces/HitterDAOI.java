package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Hitter;

public interface HitterDAOI {
	
	enum SQL{
		GET_HITTER_BY_ID("select * from player where player_id=?"),
		GET_ALL_HITTERS_BY_TEAM_ID("select * from player where team_id=?"),
		UPDATE_HITTER_STAT("update player set at_bats=at_bats+?, runs=runs+?, hits=hits+?, doubles=doubles+?, home_runs=home_runs+?, rbi=rbi+?, walks=walks+?, strikeouts=strikeouts+? where player_id=?");
		
		private final String query;
		
		private SQL(String query) {
			this.query=query;
		}
		
		public String getQuery() {
			return this.query;
		}
	}
	
	
	
	List<Hitter> getAllHittersByTeamID(int team_id) throws SQLException, ClassNotFoundException, IOException;
	
	Hitter getHittererByID(int player_id) throws SQLException, ClassNotFoundException, IOException;
	
	int updateHitterStats(int at_bats,int runs,int hits,int doubles, int home_runs,int rbi, int walks, int strikeouts, int player_id) throws SQLException, ClassNotFoundException, IOException;
}
